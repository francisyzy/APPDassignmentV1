﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentResearch.Models
{
    public class ResourceData
    {
        public List<PhysicalResource> PhysicalResources { get; set; }
        public List<AssistantResource> AssistantResources { get; set; }
        public List<ServiceType> ServiceTypes { get; set; }
        public List<ItemCategory> ItemCategories { get; set; }
    }

   public abstract class Resource
    {
        public int ResourceId { get; set; }
        public double RentalPerHour { get; set; }
    }
    public class PhysicalResource : Resource
    {
        public string ItemName { get; set; }
        public ItemCategory ItemCategory { get; set; }
    }
    public class AssistantResource : Resource
    {
        public string Name { get; set; }
        public List<ServiceType> ServiceTypes { get; set; }
    }
    public class ServiceType
    {
        public int ServiceTypeId { get; set; }
        public string ServiceTypeName { get; set; }
    }
    public class ItemCategory
    {
        public int ItemCategoryId { get; set; }
        public string ItemCategoryName { get; set; }
    }
}
